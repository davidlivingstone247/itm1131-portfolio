ITM 1131 - Web Application Development
Lesson 10 - JavaScript Fundamentals — Variables, Types & Functions

HOW TO USE
1. Extract the ZIP.
2. Open index.html.
3. Work through the 15 stages in order.
4. Open the browser Developer Tools Console for the examples.
5. Each stage is standalone and heavily commented.

PRACTICE FUNCTIONS
1. Convert Celsius to Fahrenheit
2. Check whether a number is even
3. Return a personalized greeting

BEST-PRACTICE EMPHASIS
- Default to const.
- Use let only when reassignment is needed.
- Prefer descriptive variable/function names.
- Prefer === over ==.
- Keep functions small.
- Test with multiple inputs.
- Read console errors instead of guessing.
